-- P0-A migration DESIGN, not an applied Flyway migration. Assign a fresh V number at P1.
-- Bind to design_record.id (UUID); design_id is not globally unique across owners.
-- Existing designs with no binding retain their native editor and native storage.
create table ui_design_document (
    design_record_id uuid primary key references design_record(id),
    editor_kind varchar(16) not null default 'ui-design' check (editor_kind = 'ui-design'),
    head_revision bigint check (head_revision between 1 and 1000000000),
    spec_digest char(64) not null check (spec_digest ~ '^[a-f0-9]{64}$')
);
create table ui_design_submission (
    submission_id varchar(80) primary key,
    design_record_id uuid not null references ui_design_document(design_record_id),
    actor_user_id uuid not null references app_user(id),
    idempotency_key varchar(80) not null,
    request_fingerprint char(64) not null,
    base_revision bigint not null check (base_revision between 0 and 1000000000),
    draft_version bigint not null default 0 check (draft_version between 0 and 1000000000),
    spec_digest char(64) not null,
    status varchar(16) not null check (status in ('DRAFT','UPLOADING','CANDIDATE','VALIDATING','VALIDATED','CONFLICT','COMMITTED','CANCELLED')),
    document_json text,
    manifest_json text,
    document_hash char(64),
    manifest_hash char(64),
    unique (design_record_id, actor_user_id, idempotency_key),
    unique (design_record_id, submission_id)
);
create table ui_design_upload (
    upload_id varchar(80) primary key,
    design_record_id uuid not null,
    submission_id varchar(80) not null,
    logical_id varchar(80) not null,
    content_version bigint not null,
    content_sha256 char(64) not null,
    byte_length bigint not null check (byte_length between 1 and 1000000000),
    durable_offset bigint not null default 0 check (durable_offset >= 0 and durable_offset <= byte_length),
    status varchar(16) not null check (status in ('DECLARED','UPLOADING','READY','REJECTED','ABORTED')),
    storage_locator text,
    foreign key (design_record_id, submission_id) references ui_design_submission(design_record_id, submission_id),
    check (status <> 'READY' or (durable_offset = byte_length and storage_locator is not null)),
    unique (submission_id, logical_id, content_version)
);
create table ui_design_validation (
    validation_id varchar(80) primary key,
    design_record_id uuid not null,
    submission_id varchar(80) not null,
    draft_version bigint not null,
    spec_digest char(64) not null,
    candidate_document_hash char(64) not null,
    candidate_manifest_hash char(64) not null,
    checked_head_revision bigint not null,
    result_document_hash char(64) not null,
    result_manifest_hash char(64) not null,
    passed boolean not null,
    report_json text not null,
    foreign key (design_record_id, submission_id) references ui_design_submission(design_record_id, submission_id),
    unique (design_record_id, validation_id)
);
create table ui_design_revision (
    design_record_id uuid not null references ui_design_document(design_record_id),
    revision bigint not null check (revision between 1 and 1000000000),
    spec_digest char(64) not null,
    document_json text not null,
    manifest_json text not null,
    document_hash char(64) not null,
    manifest_hash char(64) not null,
    actor_user_id uuid not null references app_user(id),
    validation_id varchar(80) not null,
    primary key (design_record_id, revision),
    foreign key (design_record_id, validation_id) references ui_design_validation(design_record_id, validation_id)
);
alter table ui_design_document add constraint fk_ui_design_head
    foreign key (design_record_id, head_revision) references ui_design_revision(design_record_id, revision)
    deferrable initially deferred;
create table ui_design_dependency (
    design_record_id uuid not null,
    revision bigint not null,
    role varchar(16) not null,
    logical_id varchar(80) not null,
    content_version bigint not null,
    content_sha256 char(64) not null,
    byte_length bigint not null,
    storage_locator text not null,
    primary key (design_record_id, revision, role, logical_id, content_version),
    foreign key (design_record_id, revision) references ui_design_revision(design_record_id, revision)
);
create table ui_design_receipt (
    design_record_id uuid not null,
    actor_user_id uuid not null references app_user(id),
    operation varchar(32) not null,
    idempotency_key varchar(80) not null,
    request_fingerprint char(64) not null,
    submission_id varchar(80) not null,
    committed_revision bigint not null,
    receipt_json text not null,
    primary key (design_record_id, actor_user_id, operation, idempotency_key),
    unique (submission_id),
    foreign key (design_record_id, submission_id) references ui_design_submission(design_record_id, submission_id),
    foreign key (design_record_id, committed_revision) references ui_design_revision(design_record_id, revision)
);
-- Creation uses a separate request record because no design binding exists yet.
create table ui_design_create_request (
    actor_user_id uuid not null references app_user(id),
    folder_id varchar(80) not null,
    idempotency_key varchar(80) not null,
    request_fingerprint char(64) not null,
    design_record_id uuid not null references ui_design_document(design_record_id),
    primary key (actor_user_id, folder_id, idempotency_key)
);
-- Commit runs under design_record lock + current sharing/brand recheck, then document,
-- submission and sorted dependency locks. Before writes compare head and draft/hashes
-- against the exact validation report. A lost response is recovered by receipt lookup.
-- Files are finalized before this transaction; unreferenced storage has a retention policy.
