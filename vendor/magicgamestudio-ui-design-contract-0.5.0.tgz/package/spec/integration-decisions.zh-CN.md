# 0.1.0 的接入决策

本文件规定后续实现的接入边界。接口和 SQL 在 P0-A 是契约，尚未注册 Spring Controller 或执行迁移。

## 设计与权限

正文绑定表 `ui_design_document.design_record_id` 引用现有 `design_record.id` UUID；存在该绑定即为 `ui-design`，没有绑定仍为原编辑器。不要复用 `creation_kind`（已有创建来源含义）。短 designId 遵循 `DesignRecordService.DESIGN_ID`，它在现有表中只和 owner 组成唯一键，所有内部关联必须用真实记录 UUID。

创建在同一事务内登记真实设计、目录关系、类型绑定及幂等创建回执；大文件独立上传。主页打开、标题和生命周期处理先查绑定再分派，不能为新类型创建原生 baseline。首版 API 的 revision=0 表示 SQL head_revision=NULL；正式修订从 1 开始。

读取使用 `DesignRecordService.findReadableForCurrentUser/lockReadable`；编辑使用 `lockForEditing`，保留 owner、EDITOR、VIEWER/COMMENTER 的既有区别。`lockForEditing` 已按 design -> brand 顺序复核共享授权，后续新锁顺序是 design/brand -> document -> submission -> 按稳定身份排序的素材依赖 -> receipt。回收、分享、移动等管理操作继续使用其原有所有者/目录授权，不能从编辑权限推导管理权限。

## 新窗口登录态

新窗口复用现有桌面 session partition 和同源 ASI/CAU 用户会话，经 `ReplayAccountDirectory.resolveActiveSession` 解析真实 actor，再进入现有 `IdentityService`。现有 `ReplaySessionAuthenticationFilter` 是包内类且只在登录相关链中登记，不能假定新增 `/api/ui-design/**` 自动获得此认证；P1 必须为这个 URL 范围增加明确的会话认证接线。

浏览器以同源 `credentials: include` 调用新 API，cookie 由浏览器/桌面会话管理，前端和插件不读取或复制 cookie。新写入端点要求服务器配置的同源 Origin/Sec-Fetch-Site 和会话绑定 CSRF token；不得照搬登录链的全局关闭 CSRF。桌面壳只允许登记的产品来源与自身安全传输。CORS 不开放任意 origin 携带凭证。缺少可验证用户会话返回 401，不回退管理员或 development actor headers。

## 插件连接（P1 明确协议、P3 实测）

先完成上述真实用户会话保存闭环。插件目前只支持固定发布物离线预检，没有平台登录资格。正式服务连接采用用户在平台确认的一次性配对：配对码有效 5 分钟、单次消费；签发绑定真实用户与操作/设计或目录范围的短期 access credential，最长 1 小时；refresh credential 最长 30 天、轮换并检测重用。凭证只在插件本地受限凭证存储，模型工具只返回连接 ID、到期、scope 与状态。撤销连接或权限后立即按每次请求的连接状态与当前设计权限交集拒绝访问。P1 接线时再核验已有正式授权服务是否已提供等价实现，若有则复用；不另造账号。

Bearer 服务请求仅限该连接协议，没有 cookie，不使用浏览器 CSRF 机制；scope 不包含 owner/actor 参数。传输必须 HTTPS 或平台认可的本机受限通道。离线包规格和 live Server spec 的 digest 不一致时停止提交，先升级所有消费者；不得用本地版本假装在线接口返回。

## 渲染执行边界

TypeScript 包和 Java 包承担纯结构/语义/几何；两端读取同一 schema、语义与样例，浏览器包没有 Node 文件系统依赖。节点布局与控件数值派生已可执行。PNG、真实字体塑形和导出将在独立 Node worker 中使用固定版本的 Sharp/Pango、字体及解码限制，并读取设计固定资产；P0-B/P1 接通后单独验收。不能把 Canvas 测量结果写回作者数据，也不能把旧插件的 FGUI profile 当作 PNG 重建前置条件。

## 合并和正式接收

最小闭环仅 `reject-stale`：旧基线直接 409。完整阶段的 `disjoint-fields` 只能在明确字段组上三方合并；文字/自动尺寸、image/trim/九宫格、min/max/value/step、模板/实例及父子关系为联合校验域。其它冲突返回 JSON pointer 和 base/head/candidate 值。候选 PASS 不代替合并结果 PASS，实际结果重新校验并冻结其 hash 与 checked head；事务最后 CAS 同一个 head，同时写修订、设计长期依赖、head、metadata、成功回执。

预览和人工视觉审阅始终绑定它们实际查看的候选/修订，不能迁移 PASS。对象存储和数据库不是全局事务；完成字节在事务外验证，设计授权在锁内重核，只有 READY 的设计长期依赖能进修订。取消、撤权、删除和迟到工作者的字节走保留与回收规则，不重新激活设计。

P0-A SQL 尚未应用；P1 选取当时未占用的 Flyway 编号，并在隔离 PostgreSQL 验证唯一约束竞争、CAS、回执丢失恢复和重启读取。
