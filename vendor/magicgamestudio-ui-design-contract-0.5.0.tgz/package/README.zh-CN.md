# UI 设计作者契约 0.1.0

当前分发包为 0.5.0，作者格式及原有 spec digest 保持 0.1.0。`@magicgamestudio/ui-design-contract/online` 和 Java `OnlineIntakeProtocol` 共同发布在线协议 1.3.0，协议摘要包含验证报告/正式回执 Schema。TypeScript `assertOnlineValidation` / `assertOnlineReceipt` 与 Java `OnlineReceiptContract` 执行同一约束。平台已实现真实文件接收、固定依赖、条件原生导入、标准修订、持久回执，以及原生编辑后的再次发布。BUNDLE_STORED 和验证报告仍不代表发布；仅 COMMITTED 回执确认对应版本。实际集成与限制见[正式发布记录](../../docs/ui-design/PUBLICATION-INTEGRATION.md)。下文 P0-A 的旧提交 API/回执是历史契约设计，线上以独立 1.3 协议为准。

在线 1.2 增加持久顺序分块和结构化错误：1 MiB 固定块（末块可短），逐块偏移/长度/hash 核对；每个 actor 最多 256 MiB、全局最多 768 MiB 接收中数据，七天到期，完成/取消释放块字节。`assertOnlineError` 校验可定位的问题与查询身份。历史 1.1/1.2 回执按固定旧协议继续读取；新增提交使用 1.3。详细边界与重启验证见[上传恢复记录](../../docs/ui-design/UPLOAD-RECOVERY.md)。

在线 1.3 增加服务端有限三方合并：已发布基线 B、插件候选 N、当前原生文档 C。只有资源内容与场景位置分属两侧的独立修改允许自动合并；未知字段、尺寸、裁切、文字和组件结构变更返回冲突。`prepare-commit` 固定当前 head/原生 checkpoint，重新核对最终 M 的全部文件、原生投影并重建预览；`commit` 再核权并同时比较两个版本。N 的报告与预览继续保留，回执另列 M 的 hashes/validationId，文件逐项记录实际来源。编辑窗口仍需关闭后提交，活动原生通道会拒绝提交。平台 Java `FiniteAuthoringMerge` 是合并执行端，插件只验证准备结果与回执。

平台仓库是唯一规范源。这个包是 P0-A 的可执行交付：严格 JSON、结构与语义校验、稳定字节/hash、标准命令和历史、固定像素布局、提交/回执形状与数据库约束设计。本包的离线检查与平台实际集成证据分别记录，不能据离线测试推定整个产品完成。

## 运行

要求 Node >=22、Java 21、Python 3（生成/漂移检查）。普通测试无需 Python 字体库或网络；真实测试字体、RGBA 和 OFL 已纳入夹具。

```powershell
# 本目录
npm ci --ignore-scripts
npm test
python tools/build_schema.py --check
python tools/lock_spec.py --check

# 本目录/java；使用稀疏工作区现有 Maven wrapper，独立输出，不编译业务 Server
../../../Server/mvnw.cmd -f pom.xml test
```

`src/` 是浏览器可用的 TypeScript 实现；`java/` 是独立 Java 21 adapter，打包同一 Schema 和 spec 资源。两端对 `fixtures/` 的同一数据执行校验、命令序列/hash 和布局断言。生产接收端必须将原始 JSON 交给 `parseStrict` / `CanonicalJson.parse`，不能先用会吞掉重复键或舍入数值的普通 parser。内部对象校验只适合可信解析后的对象，无法恢复已经丢失的原始 token。

## 内容

- `schema/authoring.schema.json`：完整作者正文；生成源在 `tools/build_schema.py`，`--check` 防止漂移。
- `schema/commands.schema.json`：move/frame、真文本、固定图版本引用、层序、数值命令；`AuthoringHistory` 是唯一作者历史。
- `schema/manifest.schema.json`、`requests.schema.json`、`receipt.schema.json`：正文、文件、提交、版本条件和回执的分离身份。
- `spec/semantics.zh-CN.json`：局部坐标、裁切、文字、组件覆盖、五类控件、数值规范与兼容策略。
- `spec/capabilities.json`：分别声明能表达、纯命令、真实画布、像素渲染与导出。未实现项为 false。
- `spec/submission-api.json`、`submission-states.json`、`storage-design.sql`、`integration-decisions.zh-CN.md`：P1 接口、状态、数据库唯一/CAS/锁顺序、真实身份与渲染边界。
- `fixtures/complete.authoring.json`：嵌套容器、真实 RGBA/透明裁切、OFL 中文字体、真文本、按钮双实例/覆盖/隐藏状态及未知扩展；另含 Input、Slider、Progress、List。
- `fixtures/submission-fixtures.json`：可联调的请求/回执和冲突案例，仅是契约夹具，不是已发生的服务请求。preview/overview/provenance 的条目是占位元数据，没有对应文件，所以真实文件预检会拒绝这份未完成包。

字体来自 Google Fonts 的 Noto Sans SC，以 OFL 1.1 许可按测试字符集裁剪并改名为 Magic UI Fixture Regular。来源 URL、源字节 SHA-256 和子集摘要在 `fixtures/files/font-source.json`；许可全文在同目录 `OFL.txt`。它不是产品字体，未覆盖字符不能静默替代。

## 规范发布与两仓库同步

`spec/spec-lock.json` 列出规范、语义、基础符合性夹具和真实样例文件的原字节 hash；其 `specDigest` 是 `{schemaVersion, files}` 的规范 JSON hash。提交示例使用这个 digest，所以不反向纳入 digest 的文件集合。调整 schema/语义/夹具时，发布前更新版本并同时更新两端；0.1.0 首次提交前的实现迭代不当作多个已发布版本。

插件消费 `npm pack` 生成的固定 tarball，保存源仓库提交、specDigest 和 tarball SHA-256，锁文件固定本地归档的完整性。插件不另写 Schema，也不从工作区加载任意同名包。浏览器/worker 使用这个 npm 发布物；Java 用同一提交打出的 `com.magicgamestudio:ui-design-contract:0.5.0` JAR。未发布到公共 registry 或运行中的应用。

```ts
import {parseStrict, validateDocument, hashDocument, AuthoringHistory} from '@magicgamestudio/ui-design-contract';
import {getSpecification} from '@magicgamestudio/ui-design-contract/spec';
const doc = parseStrict(rawJson);
const report = validateDocument(doc);
const spec = getSpecification('summary');
// 只有 report.valid 后才能创建历史；服务端仍需独立核权、验文件和正式保存。
```

开发更新命令按依赖顺序执行：生成 Schema → 生成普通 fixtures（离线）→ `lock_spec.py` → build → `build_submission_fixtures.mjs` → npm/Java tests → pack。`--fetch-font` 仅用于明确更新字体，下载后必须审阅源摘要与许可；普通构建不下载字体。

规范实现测试不替代 P0-B 的真实拖动、中文输入、原生 Undo/保存隔离，也不替代 P1 的 PostgreSQL/存储事务、回执查询及重启重开。
